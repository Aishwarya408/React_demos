import React from 'react'

//functional Component
// function Greet(){
//     return <h1>Hello Aishwarya</h1>
// }


// const Greet = (props) => {
//     console.log(props)
//     //props.name='Vishwas'
//     return (
//         <div>

//             <h1>
//                 Hello {props.name} a.k.a {props.heroineName}
//             </h1>
//             {props.children}
//         </div>

//     )
// }

//Destructing Props method 1 in functional components
// const Greet = ({name,heroineName}) => {
     
        
//         return (
//             <div>
    
//                 <h1>
//                     Hello {name} a.k.a {heroineName}
//                 </h1>
                
//             </div>
//         )
// }

//Destructuring props method2
const Greet = (props) => {
       const {name, heroineName} = props 
        return (
            <div>
    
                <h1>
                    Hello {name} a.k.a {heroineName}
                </h1>
               
            </div>
    
        )
    }
export default Greet