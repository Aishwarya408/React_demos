import React, { Component } from 'react'

// class Welcome extends Component {
//     render(){
//         //return <h1>Class Component</h1>
//     return <h1>Welcome {this.props.name} a.k.a {this.props.heroineName}</h1>
//     }
// }

//Destructuring props in class components
class Welcome extends Component {
    render() {
        const { name, heroineName } = this.props
        //const {state1, state2} = this.state
        return (<h1>
            Welcome {name} a.k.a {heroineName}
        </h1>
        )
    }
}

export default Welcome